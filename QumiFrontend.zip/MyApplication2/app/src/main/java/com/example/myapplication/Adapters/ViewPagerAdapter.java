package com.example.myapplication.Adapters;

import android.os.Bundle;

import com.example.myapplication.Fragments.AllChatsFragment;
import com.example.myapplication.Fragments.ServiceFragment;
import com.example.myapplication.Fragments.SocialFragment;
import com.example.myapplication.Fragments.SpamFragment;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.adapter.FragmentStateAdapter;

public class ViewPagerAdapter extends FragmentPagerAdapter {

    public ViewPagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 1:
                return new SocialFragment();
            case 2:
                return new ServiceFragment();
            case 3:
                return new SpamFragment();
            default:return new AllChatsFragment();
        }
    }

    @Override
    public int getCount() {
        return 4;
    }
}
