package com.example.myapplication;

public interface OnAdapterItemLongClickListener {
    void onAdapterItemLongClickListener(int position,boolean b);
}