package com.example.myapplication;

public interface OnAdapterItemClickListener {
    void onAdapterItemClickLister(int position);
}
